from django.db import models

# Create your models here.
# appname/models.py
from django.db import models


from django.db import models
from django.contrib.auth.models import User

class ProfileVisit(models.Model):
    user_ip = models.GenericIPAddressField()
    visited_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Visit from {self.user_ip} at {self.visited_at}"

class ResumeDownload(models.Model):
    user_ip = models.GenericIPAddressField()
    downloaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Download from {self.user_ip} at {self.downloaded_at}"

from django.db import models

class ContactMessage(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    subject = models.CharField(max_length=200, blank=True, null=True)
    message = models.TextField()
    submitted_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Message from {self.name} ({self.email})"
