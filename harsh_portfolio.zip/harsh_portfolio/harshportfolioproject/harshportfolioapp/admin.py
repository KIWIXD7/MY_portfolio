from django.contrib import admin

# Register your models here.
from django.contrib import admin
from .models import ProfileVisit, ResumeDownload

@admin.register(ProfileVisit)
class ProfileVisitAdmin(admin.ModelAdmin):
    list_display = ('user_ip', 'visited_at')
    list_filter = ('visited_at',)
    search_fields = ('user_ip',)

from django.contrib import admin
from .models import ResumeDownload

@admin.register(ResumeDownload)
class ResumeDownloadAdmin(admin.ModelAdmin):
    list_display = ('user_ip', 'downloaded_at')
    list_filter = ('downloaded_at',)
    search_fields = ('user_ip',)

from django.contrib import admin
from .models import ContactMessage

@admin.register(ContactMessage)
class ContactMessageAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'subject', 'submitted_at')
    search_fields = ('name', 'email', 'subject')
    list_filter = ('submitted_at',)

