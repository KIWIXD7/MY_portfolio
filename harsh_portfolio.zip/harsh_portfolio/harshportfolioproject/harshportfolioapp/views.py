from django.shortcuts import render

# Create your views here.
# appname/views.py
from django.http import HttpResponse

def home(request):
    return HttpResponse("Welcome to my Django project!")

from django.shortcuts import render

def port(request):
    return render(request, 'port.html')

from django.shortcuts import render
from django.http import FileResponse
from .models import ProfileVisit, ResumeDownload

def get_client_ip(request):
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[0]
    else:
        ip = request.META.get('REMOTE_ADDR')
    return ip

def profile_view(request):
    user_ip = get_client_ip(request)
    ProfileVisit.objects.create(user_ip=user_ip)
    return render(request, 'port.html')  # Use your actual template name

import os
from django.http import FileResponse, Http404
from django.conf import settings
from .models import ResumeDownload

def get_client_ip(request):
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[0]
    else:
        ip = request.META.get('REMOTE_ADDR')
    return ip

def download_resume(request):
    user_ip = get_client_ip(request)
    ResumeDownload.objects.create(user_ip=user_ip)
    
    file_path = os.path.join(settings.STATIC_ROOT, 'resume/download_resume.pdf')
    if not os.path.exists(file_path):
        raise Http404("Resume not found")
    
    response = FileResponse(open(file_path, 'rb'), content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename="resume.pdf"'
    return response


from django.shortcuts import render, redirect
from .forms import ContactMessageForm

def contact_view(request):
    if request.method == 'POST':
        form = ContactMessageForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('contact_success')  # Redirect to a success page
    else:
        form = ContactMessageForm()
    return render(request, 'port.html', {'form': form})

def contact_success_view(request):
    return render(request, 'contact_success.html')  # Simple success message template
