# appname/urls.py
from django.urls import path
from . import views

urlpatterns = [
    
    path('', views.profile_view, name='port'),
    path('download-resume/', views.download_resume, name='download_resume'),
    path('contact/', views.contact_view, name='contact'),
    path('contact-success/', views.contact_success_view, name='contact_success'),
    
]
